﻿const books = [
  {
    title: "The Sunken Gate",
    tagline: "A drowned city. A door that remembers.",
    cover: "covers/sunken-gate.jpg",
    buy: "https://www.amazon.com/author/jeffwilleford"
  },
  {
    title: "The Host’s Last Word",
    tagline: "He died speaking the truth.",
    cover: "covers/hosts-last-word.jpg",
    buy: "https://www.amazon.com/author/jeffwilleford"
  },
  {
    title: "The Heart of the Black Sun",
    tagline: "A journey to the unknown. A fight to save all.",
    cover: "covers/heart-black-sun.jpg",
    buy: "https://www.amazon.com/author/jeffwilleford"
  }
];

function renderBooks() {
  const grid = document.getElementById("book-grid");
  grid.innerHTML = books.map(b => `
    <article class="card">
      <img class="cover" src="${b.cover}" alt="Cover of ${b.title}"
           onerror="this.onerror=null;this.src='https://via.placeholder.com/600x800?text=Missing+Cover';" />
      <div class="body">
        <h4>${b.title}</h4>
        <p>${b.tagline ?? ""}</p>
      </div>
      <div class="btnrow">
        <a class="buy" href="${b.buy}" target="_blank" rel="noopener">View on Amazon</a>
      </div>
    </article>
  `).join("");
}

document.getElementById("year").textContent = new Date().getFullYear();
renderBooks();
